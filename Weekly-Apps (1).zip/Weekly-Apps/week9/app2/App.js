import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter, Routes,Route } from 'react-router-dom';
import Navigation from './Components/Navigation';
import Home from './Components/Home';
import About from './Components/About';
import Products from './Components/Products';
import Contact from './Components/Contact';

function App() {
  return (
    <BrowserRouter>
    <div className='p-4 font-sans'>
     <Navigation />
     <div className='container mt-4'>
      <Routes>
           <Route path='/' element={<Home />}/>
           <Route path='/about' element={<About />}/>
           <Route path='/products' element={<Products />}/>
           <Route path='/contact' element={<Contact />}/>
      </Routes>
     </div>
    </div>
    </BrowserRouter>
  );
}

export default App;
