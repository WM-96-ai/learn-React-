import React from 'react';

const Contact=()=>{

    return(
          <h2>Welcome to you, You are in the Contact Page</h2>
    );
}

export default Contact;