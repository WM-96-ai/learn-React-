import React from 'react';

const About=()=>{

    return(
          <h2>Welcome to you, You are in the About Page</h2>
    );
}

export default About;