import React from 'react';

const Products=()=>{

    return(
          <h2>Welcome to you, You are in the Product Page</h2>
    );
}

export default Products;