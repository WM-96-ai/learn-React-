// open terminal from the server sub folder
// initial package.json using the following command     npm init -y
// update manually the package.json file with the required parameters like "type":"module" and "dev":"nodemon index.js"
// from the server terminal install the following
// npm install nodemon --save
// npm install express --save
// npm install mongoose
// npm install cors
// to run the server type:
// npm run dev


import express, { json } from 'express';
import mongoose from 'mongoose';
import cors from 'cors';

const myApp = express();
const PORT = 3003;

myApp.use(express.json());
myApp.use(cors());

const myDB = 'ProductsDB';

mongoose.connect(`mongodb+srv://admin:admin123@cluster0.555tvu8.mongodb.net/${myDB}`);

const mySchema = mongoose.Schema({
    pcode: Number,
    category: String,
    pname: String,
    price: Number,
    imgUrl: String,
});

const myModel = mongoose.model('products_collections', mySchema);



myApp.get("/products", async (req, res) => {
    try {
        const products = await myModel.find();
        res.json(products);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server error, please try again later" });
    }
});

myApp.get("/products-table", async (req, res) => {
    try {
        const products = await myModel.find();

        let tableRows = products.map(product => `
            <tr>
                <td>${product.pcode}</td>
                <td>${product.category}</td>
                <td>${product.pname}</td>
                <td>${product.price}</td>
                <td><img src="${product.imgUrl}" width="100"/></td>
            </tr>
        `).join('');

        const htmlContent = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Products Table</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
            </head>
            <body>
                <div class="container mt-5">
                    <h2 class="mb-4">Products List</h2>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Product Code</th>
                                <th>Category</th>
                                <th>Name</th>
                                <th>Price</th>
                                <th>Image</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${tableRows}
                        </tbody>
                    </table>
                </div>
            </body>
            </html>
        `;

        res.send(htmlContent);

    } catch (error) {
        console.error(error);
        res.status(500).send("Server error, please try again later");
    }
});

myApp.listen(PORT, () => {
    console.log('You Are Connected');
    console.log(`You Server running on http://localhost:${PORT}`);
    console.log(`You are connected to ${myDB} database`);
})