import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';

function Home() {
  return <h2>Welcome to the Home Page component</h2>
}

function About() {
  return <h2>Welcome to the About Page component</h2>
}

function Products() {
  return <h2>Welcome to the Products Page component</h2>
}

function Contact() {
  return <h2>Welcome to the Contact Page component</h2>
}



function App() {
  return (
    <BrowserRouter>
      <div className='p-4 font-sans'>
        <Navbar className='mb-4' bg='light' expand='lg'>
          <Container>
              <Nav className='me-auto'>
                 <Nav.Link as={Link} to="/">Home</Nav.Link>
                 <Nav.Link as={Link} to="/about">About</Nav.Link>
                 <Nav.Link as={Link} to="/products">Products</Nav.Link>
                 <Nav.Link as={Link} to="/contact">Contact As</Nav.Link>
              </Nav>
          </Container>
        </Navbar>
        <Routes>
          <Route path='/' element={<Home />}/>
          <Route path='/about' element={<About />}/>
          <Route path='/products' element={<Products />}/>
          <Route path='/contact' element={<Contact />}/>
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
