document.getElementById("jobForm").addEventListener("submit", function(event) {
    let valid = true;
    
    const name = document.getElementById("name").value.trim();
    if (name === "") {
        alert("Name cannot be empty.");
        valid = false;
    }
    
    const email = document.getElementById("email").value.trim();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert("Please enter a valid email address.");
        valid = false;
    }
    
    const phone = document.getElementById("phone").value.trim();
    const phonePattern = /^\d{10}$/;
    if (!phonePattern.test(phone)) {
        alert("Please enter a valid 10-digit phone number.");
        valid = false;
    }
    
    const genderMale = document.getElementById("male").checked;
    const genderFemale = document.getElementById("female").checked;
    if (!genderMale && !genderFemale) {
        alert("Please select a gender.");
        valid = false;
    }
    
    if (!valid) {
        event.preventDefault();
    }
});
