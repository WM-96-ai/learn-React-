import React, { useState } from 'react';
import axios from 'axios';

const DeleteProduct = () => {
    const [pcode, setPcode] = useState('');

    const handleDelete = async (e) => {
        e.preventDefault();

        if (!pcode.trim()) {
            alert('Please enter a product code');
            return;
        }
        try {
            // Check if product exists
            const response = await axios.get(`http://localhost:3003/products/${pcode}`);

            if (response.data) {
                // Product found, proceed to delete
                const deleteRes = await axios.delete(`http://localhost:3003/delete-product/${pcode}`);
                alert('Product deleted successfully!');
            }
        } catch (error) {
            if (error.response && error.response.status === 404) {
                alert('Product not found!');
            } else {
                alert('Server error. Please try again later.');
                console.error(error);
            }
        }
    };
    return (
        <div style={{ margin: '20px', padding: '20px', border: '1px solid gray', borderRadius: '10px' }}>
            <h2>Delete Product by Code</h2>
            <form onSubmit={handleDelete}>
                <input
                    type="text"
                    placeholder="Enter Product Code"
                    value={pcode}
                    onChange={(e) => setPcode(e.target.value)}
                    style={{ padding: '10px', marginRight: '10px' }}
                />
                <button type="submit" style={{ padding: '10px 20px' }}>Delete</button>
            </form>
        </div>
    );
};
export default DeleteProduct;
