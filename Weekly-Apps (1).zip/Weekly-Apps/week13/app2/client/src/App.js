
import DeleteProduct from './DeleteProduct';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (

    <div className="App">
      <DeleteProduct />

    </div>


  );
}

export default App;
