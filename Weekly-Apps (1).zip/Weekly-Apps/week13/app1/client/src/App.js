import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Display from './Display';
import AddProduct from './AddProduct';
import UpdateProduct from './UpdateProduct';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Display />} />
          <Route path="/add-product" element={<AddProduct />} />
          <Route path="/update" element={<UpdateProduct />} />
        </Routes>
      </div>
    </Router>

  );
}

export default App;
