import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useLocation, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const UpdateProduct = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const product = location.state?.product;

  // Separate states for each field
  const [pcode, setPcode] = useState('');
  const [category, setCategory] = useState('');
  const [pname, setPname] = useState('');
  const [price, setPrice] = useState('');
  const [imgUrl, setImgUrl] = useState('');

  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  useEffect(() => {
    if (product) {
      setPcode(product.pcode);
      setCategory(product.category);
      setPname(product.pname);
      setPrice(product.price);
      setImgUrl(product.imgUrl);
    }
  }, [product]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:3003/update-product/${pcode}`, {
        pname,
        price: parseFloat(price),
        category,
        imgUrl,
      });
      setSuccessMessage('Product updated successfully!');
      setTimeout(() => navigate('/'), 1500);
    } catch (err) {
      console.error('Error updating product:', err);
      setError('Failed to update product. Please try again.');
    }
  };

  const handleCancel = () => {
    navigate('/');
  };

  return (
    <div className="container mt-4">
      <h1 className="text-center mb-4">Update Product</h1>
      {error && <div className="alert alert-danger">{error}</div>}
      {successMessage && <div className="alert alert-success">{successMessage}</div>}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label className="form-label">Product Code</label>
          <input type="number" className="form-control" value={pcode} readOnly />
        </div>
        <div className="mb-3">
          <label className="form-label">Category</label>
          <input type="text" className="form-control" value={category} onChange={(e) => setCategory(e.target.value)} required />
        </div>
        <div className="mb-3">
          <label className="form-label">Product Name</label>
          <input type="text" className="form-control" value={pname} onChange={(e) => setPname(e.target.value)} required />
        </div>
        <div className="mb-3">
          <label className="form-label">Price</label>
          <input type="number" step="0.01" className="form-control" value={price} onChange={(e) => setPrice(e.target.value)} required />
        </div>
        <div className="mb-3">
          <label className="form-label">Image URL</label>
          <input type="text" className="form-control" value={imgUrl} onChange={(e) => setImgUrl(e.target.value)} required />
        </div>
        <button type="submit" className="btn btn-primary w-100">Update Product</button>
        <button type="button" className="btn btn-secondary w-100 mt-2" onClick={handleCancel}>Cancel</button>
      </form>
    </div>
  );
};

export default UpdateProduct;
