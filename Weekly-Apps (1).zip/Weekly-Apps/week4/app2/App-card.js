import React from "react";
import Calculate from "./Calculate"; // Adjust the path as necessary
import employeeData from "./employee.json"; // Adjust the path as necessary
import "bootstrap/dist/css/bootstrap.min.css"; // Import Bootstrap CSS

const EmployeeDetails = ({ employee }) => {
  const { fullName, address, bSalary, benefits, grade } = employee;
  const grandTotal = Calculate(bSalary, grade, benefits);

  return (
    <div className="card mb-3">
      <div className="card-body">
        <h5 className="card-title">{fullName}</h5>
        <p className="card-text">Address: {address}</p>
        <p className="card-text">Base Salary: ${bSalary}</p>
        <p className="card-text">Benefits: ${benefits}</p>
        <p className="card-text">Grade: {grade}</p>
        <p className="card-text">
          <strong>Grand Total Salary:</strong> ${grandTotal}
        </p>
      </div>
    </div>
  );
};

const App = () => {
  return (
    <div className="container mt-5">
      <h1 className="mb-4">Employee Details</h1>
      {employeeData.map((employee) => (
        <EmployeeDetails key={employee.eId} employee={employee} />
      ))}
    </div>
  );
};

export default App;
