const Calculate = (bSalary, grade, benefits) => {
  var grandSal = 0;

  if(grade>0 && grade <=5){
    grandSal = bSalary + benefits + bSalary * 0.5;
  }
  else if(grade > 5){
    grandSal = 2 * bSalary + benefits;
  }
  
  return grandSal;
};

export default Calculate;
