// after install react app using npx create-react-app .
// you must install bootstrap using npm install bootstrap

import React from 'react';
import Calculate from './Calculate'; // Adjust the path as necessary
import employeeData from './employee.json'; // Adjust the path as necessary
import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS

const App = () => {
  return (
    <div className="container mt-5">
      <h1 className="mb-4">Employee Details</h1>
      <table className="table table-hover">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Employee ID</th>
            <th scope="col">Full Name</th>
            <th scope="col">Address</th>
            <th scope="col">Base Salary</th>
            <th scope="col">Benefits</th>
            <th scope="col">Grade</th>
            <th scope="col">Grand Total Salary</th>
          </tr>
        </thead>
        <tbody>
          {employeeData.map((employee, index) => (
            <tr>
              <th>{index + 1}</th>
              <th>{employee.eId}</th>
              <td>{employee.fullName}</td>
              <td>{employee.address}</td>
              <td>${employee.bSalary}</td>
              <td>${employee.benefits}</td>
              <td>{employee.grade}</td>
              <td>${Calculate(employee.bSalary, employee.grade, employee.benefits)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default App;
