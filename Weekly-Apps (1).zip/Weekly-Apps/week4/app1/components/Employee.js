import React, { useState } from "react";

const Employee = () => {
    const [myData, setMyData] = useState("Mohamed Al Ajmi")
    return (
        <>
            <span className="display-5">{myData}</span>
        </>
    );
}
export default Employee;