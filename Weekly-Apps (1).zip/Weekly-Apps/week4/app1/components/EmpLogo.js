import emp_logo from "../components/male2.jpeg";


const EmpLogo = () => {
    return (
        <>
            <img src={emp_logo} className="rounded-circle" alt="logo" style={{ height: "300px", width: "300px", objectFit: "cover" }}
            />
        </>
    );
}
export default EmpLogo;
