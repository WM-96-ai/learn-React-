
const EmpList = () => {
    const emp_A = [
        { empId: 81742, empName: "Hamid Naser Hakim", status: true, joinYear: 2005 },
        { empId: 27329, empName: "Medhat Mikha'il Alfarsi", status: true, joinYear: 2008 },
        { empId: 14289, empName: "Gamila Aqila Umar", status: false, joinYear: 2016 },
        { empId: 60845, empName: "Amany Jamillah Omar", status: false, joinYear: 2004 },
        { empId: 69313, empName: "Duaa Rafiqa Mohammed", status: false, joinYear: 2015 }
    ]
    const emp_B = [
        { empId: 79095, empName: "Huda Rajya Al-Ghazzawi", status: false, joinYear: 2014 },
        { empId: 42489, empName: "Ghada Rayan Salim", status: false, joinYear: 2011 },
        { empId: 69469, empName: "Hasim Hussain El-Hashem", status: true, joinYear: 2008 },
        { empId: 69999, empName: "Mohamed Salil Umar", status: true, joinYear: 2009 },
        { empId: 66985, empName: "Hussein Daniyal Saqqaf", status: true, joinYear: 2005 }
    ]
    const emp_C = [
        { empId: 75566, empName: "Nazim Baqir Nejem", status: true, joinYear: 2007 },
        { empId: 47186, empName: "Mouna Baqir Abdulrashid", status: false, joinYear: 2005 },
        { empId: 55845, empName: "Muhammad Qusay Khatib", status: true, joinYear: 2015 },
        { empId: 71144, empName: "Daniyal Nazim Salim", status: true, joinYear: 2007 },
        { empId: 75319, empName: "Shayma Mohammed Ahmed", status: false, joinYear: 2020 }
    ]
    const emp_list = [...emp_A, ...emp_B]
    return (
        <>
            <table className="table table-striped">
                <thead className="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Employee Name</th>
                        <th>Status</th>
                        <th>Join Year</th>
                        <th>Experience</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        emp_list.map((emp) => {
                            const curYear = new Date().getFullYear()
                            const exp = (curYear - emp.joinYear) * 52
                            return (
                                <>
                                    <tr>
                                        <td>{emp.empId}</td>
                                        <td>{emp.empName}</td>
                                        <td>{(emp.status) ? "Male" : "Female"}</td>
                                        <td>{emp.joinYear}</td>
                                        <td>{exp} Weeks</td>
                                    </tr>
                                </>
                            )
                        })
                    }
                </tbody>
            </table>
        </>
    );
}
export default EmpList;
