import "bootstrap/dist/css/bootstrap.min.css";
import Employee from "./components/Employee";
import EmpLogo from "./components/EmpLogo";
import EmpList from "./components/EmpList";


function App() {
  return (
    <>
      <div id="main" className="container-fluid">
        <div id="header" className="container-fluid bg-warning p-4 d-flex justify-content-center align-items-center mb-3">{<Employee />}</div>
        <div id="display" className="row">
          <div id="left" className="col-3 d-flex justify-content-center align-items-center">{<EmpLogo />}</div>
          <div id="right" className="col-9">{<EmpList />}</div>
        </div>
        <div id="footer" className="container-fluid bg-info p-4 d-flex justify-content-center align-items-center">{<Employee />}</div>

      </div>

    </>
  );
}

export default App;
