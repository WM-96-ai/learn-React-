import mongoose from 'mongoose';

const myDB = 'ProductsDB';

mongoose.connect(`mongodb+srv://admin:admin123@cluster0.555tvu8.mongodb.net/${myDB}`);

const mySchema = new mongoose.Schema({
    pcode: { type: Number, required: true },
    category: { type: String, required: true },
    pname: { type: String, required: true },
    price: { type: Number, required: true },
    imgUrl: { type: String, required: true },
},
    { versionKey: false }
);

const myModel = mongoose.model('products_collections', mySchema);


export { myModel, myDB };
