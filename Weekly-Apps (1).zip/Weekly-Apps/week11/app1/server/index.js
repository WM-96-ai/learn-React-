// open terminal from the server sub folder
// initial package.json using the following command     npm init -y
// update manually the package.json file with the required parameters like "type":"module" and "dev":"nodemon index.js"
// from the server terminal install the following
// npm install nodemon --save
// npm install express --save
// npm install mongoose
// npm install cors
// if you have a complete package.json file than in the folder that has the package.json run the following
// to install all the required Packages using :
// npm install
// to run the server type:
// npm run dev


import express, { json } from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import { myModel, myDB } from './SchemaModel.js';

const myApp = express();
const PORT = 3003;

myApp.use(express.json());
myApp.use(cors());




// http://localhost:3003/products/

myApp.get("/products", async (req, res) => {
    try {
        const products = await myModel.find();
        res.json(products);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server error, please try again later" });
    }
});

// get product by pcode

// http://localhost:3003/products/222

myApp.get("/products/:pcode", async (req, res) => {
    try {
        const { pcode } = req.params;
        const product = await myModel.findOne({ pcode });

        if (product) {
            res.json(product);
        } else {
            res.status(404).json({ message: "Product not found" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server error, please try again later" });
    }
});

// http://localhost:3003/products/category/Samsung

myApp.get("/products/category/:pcat", async (req, res) => {
    try {
        const { pcat } = req.params;
        const products = await myModel.find({ category: pcat });

        if (products.length > 0) {
            res.json(products);
        } else {
            res.status(404).json({ message: "No products found by this author" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server error, please try again later" });
    }
});

/*
{
    "pcode": 444,
    "category": "HUAWEI",
    "pname": "Mate 20 Pro",
    "price": 300.5,
    "imgUrl": "https://example.com/images/mate20pro.jpg"
}

*/


myApp.post("/products/add", async (req, res) => {
    try {
        const { pcode, category, pname, price, imgUrl } = req.body;

        if (!pcode || !category || !pname || !imgUrl) {
            return res.status(400).json({ message: "Missing required fields" });
        }

        const newProduct = await myModel.create({
            pcode: Number(pcode),
            category,
            pname,
            price: price || 400,
            imgUrl
        });

        console.log(`New product added: ${newProduct}`);
        res.status(201).json(newProduct);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server error, please try again later" });
    }
});

/*on Thunder client use put method with the following URL  http://localhost:3003/update-product/444
in request body under JSON to update pname and price

{
  "pname":"Mate 20 Pro Plus",
  "price":400
}


*/

myApp.put("/update-product/:pcode", async (req, res) => {
    try {
        const { pcode } = req.params;
        const updateData = req.body;

        if (!updateData || Object.keys(updateData).length === 0) {
            return res.status(400).json({ message: "No data provided to update" });
        }

        const updatedProduct = await myModel.findOneAndUpdate(
            { pcode: Number(pcode) },
            updateData,
            { new: true }
        );

        if (updatedProduct) {
            console.log(`Product updated: ${JSON.stringify(updatedProduct)}`);
            res.status(200).json({ message: "Product updated successfully", updatedProduct });
        } else {
            res.status(404).json({ message: "Product not found" });
        }
    } catch (error) {
        console.error("Error updating product:", error);
        res.status(500).json({ message: "Server error, please try again later" });
    }
});

//on Thunder client use delete method with the following URL  http://localhost:3003/delete-product/555

myApp.delete("/delete-product/:pcode", async (req, res) => {
    try {
        const { pcode } = req.params;
        const deletedProduct = await myModel.findOneAndDelete({ pcode: Number(pcode) });

        if (deletedProduct) {
            console.log(`Product deleted: ${deletedProduct}`);
            res.status(200).json({ message: "Product deleted successfully", deletedProduct });
        } else {
            res.status(404).json({ message: "Product not found" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Server error, please try again later" });
    }
});


//on Thunder client use delete method with the following URL  http://localhost:3003/delete-products/IPhone

myApp.delete("/delete-products/:cat", async (req, res) => {
    try {
        const { cat } = req.params;
        const deletedProducts = await myModel.deleteMany({ category: cat });

        if (deletedProducts.deletedCount > 0) {
            console.log(`Deleted ${deletedProducts.deletedCount} product(s) in category: ${cat}`);
            res.status(200).json({
                message: `${deletedProducts.deletedCount} product(s) deleted successfully`,
                deletedCount: deletedProducts.deletedCount,
            });
        } else {
            res.status(404).json({ message: "No products found in the specified category" });
        }
    } catch (error) {
        console.error("Error deleting products by category:", error);
        res.status(500).json({ message: "Server error, please try again later" });
    }
});


myApp.listen(PORT, () => {
    console.log('You Are Connected');
    console.log(`You Server running on http://localhost:${PORT}`);
    console.log(`You are connected to ${myDB} database`);
})