import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import StudentRow from './StudentRow';




const App = () => {
  const students = [
    {id:111,name:'Ali',age:22},
    {id:112,name:'Ahmed',age:20},
    {id:113,name:'Sara',age:21}
  ]
  return (
    <>
      {/* 
    <div className='container d-flex justify-content-start bg-primary text-white border p-3 mt-3'>
      <h3>fixed width container </h3>
      <p>This container has fixed width </p>
    </div>
*/}

      <div className='container  d-flex justify-content-center bg-primary text-white border m-4 p-4'>
        <table className='table table-striped table-bordered table-hover'>
          <thead className='table-dark'>
           <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Age</th>
           </tr>
          </thead>
          <tbody className='tbody'>
            {/* 
           {students.map(student=><StudentRow key={student.id}{...student} />)}
            */}

            {students.map(student=><StudentRow key={student.id} id={student.id} name={student.name} age={student.age}/>)}
          </tbody>

        </table>
      </div>

    </>
  );
}

export default App;
