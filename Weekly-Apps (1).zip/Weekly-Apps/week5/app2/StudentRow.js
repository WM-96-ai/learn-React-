const StudentRow =({id,name,age})=>{

    return(
     <tr>
      <td>{id}</td>
      <td>{name}</td>
      <td>{age}</td>
     </tr>
    )
  }

  export default StudentRow;