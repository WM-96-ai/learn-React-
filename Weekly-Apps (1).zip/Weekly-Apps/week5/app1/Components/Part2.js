import Logo from "./cars.png";

const Part2 = () => {
  return (
    <>
      <div class="container m-4 d-flex justify-content-center">
        <img src={Logo} className="rounded-circle img-thumbnail" alt="logo" style={{ height: "10%", width: "10%", objectFit: "cover" }}/>
      </div>
    </>
  );
};

export default Part2;
