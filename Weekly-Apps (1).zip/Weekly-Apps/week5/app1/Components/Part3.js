const Part3 = () => {
  const data = [
    { carId: 1, carName: "Toyota Corolla", carModel: 2022, carPrice: 25000 },
    { carId: 2, carName: "Honda Civic", carModel: 2023, carPrice: 27000 },
    { carId: 3, carName: "Ford Mustang", carModel: 2021, carPrice: 55000 },
    { carId: 4, carName: "Chevrolet Camaro", carModel: 2020, carPrice: 48000 },
    { carId: 5, carName: "BMW 3 Series", carModel: 2023, carPrice: 60000 },
    { carId: 6, carName: "Audi A4", carModel: 2022, carPrice: 58000 },
    { carId: 7, carName: "Mercedes-Benz C-Class", carModel: 2021, carPrice: 65000 },
    { carId: 8, carName: "Tesla Model 3", carModel: 2024, carPrice: 45000 },
    { carId: 9, carName: "Nissan Altima", carModel: 2022, carPrice: 28000 },
    { carId: 10, carName: "Hyundai Elantra", carModel: 2023, carPrice: 24000 }
  ];


  const curYear = new Date().getFullYear();
  const depreciationRate = 0.06; // 6% per year

  // Function to calculate the current price after depreciation
  const calculateCurrentPrice = (originalPrice, carAge) => {
    return (originalPrice * Math.pow(1 - depreciationRate, carAge)).toFixed(2);
  };

  return (
    <>
      <div className="row">
        <div className="col-5 justify-content-start"></div>

        <div className="col-7 justify-content-end">
        
            <table className="table table-hover table-striped table-bordered">
              <thead className="table-dark">
                <tr>
                  <th>Car ID</th>
                  <th>Car Name</th>
                  <th>Car Model</th>
                  <th>Manufacture Price</th>
                  <th>Car Age</th>
                  <th>Current Price</th>
                </tr>
              </thead>

              <tbody className="table-group-divider">
                {data.map((car) => {
                  const carAge = curYear - car.carModel;
                  const currentPrice = calculateCurrentPrice(car.carPrice, carAge);
                  return (
                    <tr>
                      <td>{car.carId}</td>
                      <td>{car.carName}</td>
                      <td>{car.carModel}</td>
                      <td>${car.carPrice.toLocaleString()}</td>
                      <td>{carAge}</td>
                      <td>${currentPrice.toLocaleString()}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          
        </div>
      </div>
    </>
  );
};

export default Part3;
