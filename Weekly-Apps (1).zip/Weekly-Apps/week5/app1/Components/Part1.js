import Logo from "./cars.jpeg";

const Part1 = () => {
  return (
    <>
      <div class="container-fluid d-flex justify-content-start">
        <img src={Logo} className="rounded-circle img-thumbnail p-3" alt="" style={{ height: "10%", width: "10%", objectFit: "cover" }} />
      </div>
    </>
  );
};

export default Part1;
