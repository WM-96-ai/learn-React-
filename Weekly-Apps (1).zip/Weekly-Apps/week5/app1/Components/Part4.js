import React, { useState } from "react";
const Part4 = () => {

  const today = new Date();
  const today1 = today.toDateString()
  const [preparedBy, setpreparedBy] = useState("Mohamed Al-Ajmi");
  const [preparedOn, setpreparedOn] = useState(today1);

  return (
    <>
      <div className="row justify-content-center">
        <div className="col-8">
          <h3>Prepared by {preparedBy}</h3>
          <h3>Printed On: {preparedOn}</h3>
        </div>

      </div>
    </>
  );
};

export default Part4;
