import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const AddProduct = () => {
    const [pcode, setPcode] = useState('');
    const [category, setCategory] = useState('');
    const [pname, setPname] = useState('');
    const [price, setPrice] = useState('');
    const [imgUrl, setImgUrl] = useState('');

    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:3003/products/add', {
                pcode: Number(pcode),
                category: category,
                pname: pname,
                price: parseFloat(price),
                imgUrl: imgUrl
            });
            //alert('Product added successfully!');
            navigate('/'); // Redirect back to Display.js
        } catch (error) {
            console.error('Error adding product:', error);
            alert('Failed to add product. Please try again.');
        }
    };

    return (
        <div className="container mt-5">
            <h2 className="text-center mb-4">Add New Product</h2>
            <form onSubmit={handleSubmit} className="mx-auto" style={{ maxWidth: '500px' }}>
                <div className="mb-3">
                    <label className="form-label">Product Code</label>
                    <input
                        type="number"
                        className="form-control"
                        value={pcode}
                        onChange={(e) => setPcode(e.target.value)}
                        required
                    />
                </div>

                <div className="mb-3">
                    <label className="form-label">Category</label>
                    <input
                        type="text"
                        className="form-control"
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        required
                    />
                </div>

                <div className="mb-3">
                    <label className="form-label">Product Name</label>
                    <input
                        type="text"
                        className="form-control"
                        value={pname}
                        onChange={(e) => setPname(e.target.value)}
                        required
                    />
                </div>

                <div className="mb-3">
                    <label className="form-label">Price</label>
                    <input
                        type="number"
                        step="0.01"
                        className="form-control"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        required
                    />
                </div>

                <div className="mb-3">
                    <label className="form-label">Image URL</label>
                    <input
                        type="text"
                        className="form-control"
                        value={imgUrl}
                        onChange={(e) => setImgUrl(e.target.value)}
                        required
                    />
                </div>

                <button type="submit" className="btn btn-success w-100">Add Product</button>
            </form>
        </div>
    );
};

export default AddProduct;
