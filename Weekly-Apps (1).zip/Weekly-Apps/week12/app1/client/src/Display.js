import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router-dom';

const Display = () => {
    const [products, setProducts] = useState([]);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await axios.get('http://localhost:3003/products');
                setProducts(response.data);
            }
            catch (err) {
                console.error('Error in fetching products', err);
                setError('Unable to fetch products. please try again');
            }
        };
        fetchProducts();
    }, []);

    const handleAddProduct = () => {
        navigate('/add-product');
    };

    const handleDelete = async (pcode) => {
        try {
            await axios.delete(`http://localhost:3003/delete-product/${pcode}`);
            setProducts(products.filter(product => product.pcode !== pcode));
        } catch (err) {
            console.error(`Failed to delete product with pcode ${pcode}:`, err);
            alert("Delete failed. Please try again.");
        }
    };

    return (
        <div className='container mt-5'>
            <h2 className='text-center mb-4'>Products List</h2>

            <div className="text-center mb-4">
                <button className="btn btn-primary" onClick={handleAddProduct}>
                    Add New Product
                </button>
            </div>

            {error && <div className='alert alert-danger'>{error}</div>}
            {!error && (
                <table className='table table-striped table-bordered'>
                    <thead>
                        <tr>
                            <th>SN</th>
                            <th>Code</th>
                            <th>Category</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Image</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {products.map((product, index) => (
                            <tr key={product._id}>
                                <td>{index + 1}</td>
                                <td>{product.pcode}</td>
                                <td>{product.category}</td>
                                <td>{product.pname}</td>
                                <td>{product.price}</td>
                                <td><img src={product.imgUrl} alt={product.pname} style={{ width: "100px", height: "100px" }} /></td>
                                <td><button className="btn btn-danger" onClick={() => handleDelete(product.pcode)}>Delete</button></td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    )
}

export default Display;
