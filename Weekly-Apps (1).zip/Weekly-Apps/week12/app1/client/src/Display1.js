import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const Display1 = () => {
    const [products, setProducts] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchProducts = async () => {
            try {
                const response = await axios.get('http://localhost:3003/products');
                setProducts(response.data);
            }
            catch (err) {
                setError('Unable to fetch products. Please try again.');
            }
        };
        fetchProducts();
    }, []);

    return (
        <div className="container mt-5">
            <h2 className="text-center mb-4">Products Gallery</h2>
            {error && <div className="alert alert-danger">{error}</div>}
            <div className="row">
                {!error && products.map(product => (
                    <div className="col-md-4 mb-4" key={product._id}>
                        <div className="card h-100">
                            <img
                                src={product.imgUrl}
                                className="card-img-top"
                                alt={product.pname}
                                style={{ height: '200px', objectFit: 'cover' }}
                            />
                            <div className="card-body">
                                <h5 className="card-title">{product.pname}</h5>
                                <p className="card-text"><strong>Code:</strong> {product.pcode}</p>
                                <p className="card-text"><strong>Category:</strong> {product.category}</p>
                                <p className="card-text"><strong>Price:</strong> ${product.price}</p>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Display1;
