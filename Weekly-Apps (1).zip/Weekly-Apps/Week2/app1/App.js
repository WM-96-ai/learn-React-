// Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser     run this once in a new pc inside terminal
// npm install npx                                                          run this once in a new pc inside terminal
// npx create-react-app .
// npm install bootstrap

import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const myFriendsArray = [
    {
      civilId: 68541255,
      name: "Mohammed Fahad",
      dob: "14-Jul-1999",
      city: "Nizwa"
    },
    {
      civilId: 77556614,
      name: "Hamed Mazin",
      dob: "22-Aug-2003",
      city: "Muscat"
    },
    {
      civilId: 15476628,
      name: "Aida Qassim",
      dob: "03-Dec-2001",
      city: "Salalah"
    },
    {
      civilId: 90002457,
      name: "Moza Sulaiman",
      dob: "28-Feb-2003",
      city: "Muscat"
    }
  ]
  const myLogo = "https://www.utas.edu.om/portals/0/Images/utas-logo.png";
  return (
    <>
      <div id="main" className="container-fluid">

        <div id="title" className="d-flex justify-content-center align-items-center bg-info" style={{ height: "100px" }}>
          <span id="pageTitle" className="text-white display-1">Welcome to Bootstrap</span>
        </div>

        <div id="pageBody" className="container bg-secondary-subtle my-4">
          <div id="myDetails" className="row p-5">

            <div id="myCourses" className="col-3 p-4 text-danger">
              <h3 className="text-danger p-3">My Courses</h3>
              <ul>
                <li>Advanced Web Technologies</li>
                <li>Artificial Intelligence</li>
                <li>Formal Arabic Communications</li>
                <li>Introduction to Data Science</li>
                <li>Course Project I</li>
              </ul>
            </div>

            <div id="mySelf" className="col-5 p-4">
              <h3 className="text-danger p-3">About Myself</h3>
              <p>Aenean pulvinar velit eu nibh tempor, at blandit leo ullamcorper. Sed urna mauris, fringilla nec risus vel, congue iaculis erat. Mauris mattis gravida porta. Mauris gravida convallis euismod. Cras sed ullamcorper quam. Etiam et urna sit amet quam congue dictum in lobortis tortor. Etiam porttitor, eros a posuere pulvinar, purus urna feugiat lectus, sodales semper sem libero sed lorem. Donec eu neque nibh. Praesent vehicula lorem mi. Nullam nec consectetur metus. Proin dapibus purus nec aliquam fringilla. Nunc pulvinar lacinia dui eu dictum. In posuere, tortor et hendrerit vulputate, augue elit interdum nisl, vitae faucibus libero nunc eget dui. Etiam a tortor blandit, mollis urna nec, facilisis erat.</p>
            </div>


            <div id="myFriends" className="col p-4">
              <h3 className="text-danger p-3">My Friends</h3>
              <table className="table table-bordered table-striped">
                <thead className='bg-dark text-white'>
                  <tr>
                    <th>Civil ID</th>
                    <th>Name</th>
                    <th>City</th>
                  </tr>
                </thead>
                <tbody>
                  {myFriendsArray.map((friend, index) => (
                    <tr key={index}>
                      <td>{friend.civilId}</td>
                      <td>{friend.name}</td>
                      <td>{friend.city}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>


        <div id="pageFooter" className="container-fluid bg-warning p-2 text-end">
          <img id="logo" src={myLogo} alt="Logo" className="img-thumbnail" style={{ height: "50px" }} />
        </div>


      </div>
    </>
  );
}

export default App;
