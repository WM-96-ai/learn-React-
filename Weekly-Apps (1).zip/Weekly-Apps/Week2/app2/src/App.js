import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {

  // conditional statements
  const number = 10;
  let message;
  if (number < 5) {
    message = "The number is less than 5";
  }
  else if (number < 10) {
    message = "The number is less than 10";
  }
  else {
    message = "The number is 10 or greater";
  }

  // Ternary operator

  const isEven = number % 2 === 0 ? "Number is Even" : " Number is Odd";

  // Spread Operator

  const list1 = [1, 2, 3];
  const list2 = [...list1, 4, 5, 6];

  // String Methods examples
  const welcome = "Hello World";

  // Number Methods Examples
  const num = 12.3456;
  const num1 = '123';
  const numFixed = num.toFixed(2);
  const numInt = parseInt(num1);
  const numFloat = parseFloat('15.61');

  // Date methods examples

  const today = new Date();
  const day = today.getDay();
  const month = today.getMonth();
  const year = today.getFullYear();
  const today1 = today.toDateString()



  return (
    <div className='container'>
      <h1 className='text-primary'>React Concepts</h1>
      <div className='row'>
        <div className='col-md-6'>
          <h3>Conditional statements Examples</h3>
          <p>{message}</p>
          <p>{isEven}</p>
        </div>
        <div className='col-md-6'>
          <h3>Spread Operator Example</h3>
          <p>{list2.join(", ")}</p>
          <p>{welcome.length}</p>
          <p>{welcome.substring(0, 5)}</p>
          <p>{welcome.toUpperCase()}</p>
          <p>{welcome.toLowerCase()}</p>
          <p>{numFixed}</p>
          <p>{numInt}</p>
          <p>{numFloat}</p>
          <p>{today1}</p>
          <p>{day}</p>
          <p>{month}</p>
          <p>{year}</p>
        </div>
        
      </div>

    </div>
  );
}

export default App;
