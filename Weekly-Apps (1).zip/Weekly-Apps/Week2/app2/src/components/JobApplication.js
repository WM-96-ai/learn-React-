import React, { useState } from "react";
import "../styles/Styles.css";

const JobApplication = () => {
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        phone: "",
        address: "",
        position: "web_developer",
        gender: "",
        experience: false,
        weekends: false,
        comments: ""
    });

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData({
            ...formData,
            [name]: type === "checkbox" ? checked : value
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!formData.name.trim()) return alert("Name cannot be empty.");
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) return alert("Please enter a valid email address.");
        if (!/^\d{10}$/.test(formData.phone)) return alert("Please enter a valid 8-digit phone number.");
        if (!formData.gender) return alert("Please select a gender.");

        alert("Form submitted successfully!");
    };

    return (
        <div className="container">
            <h1>Job Application Form</h1>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label>Name:</label>
                    <input type="text" name="name" value={formData.name} onChange={handleChange} />
                </div>

                <div className="form-group">
                    <label>Email:</label>
                    <input type="email" name="email" value={formData.email} onChange={handleChange} />
                </div>

                <div className="form-group">
                    <label>Phone:</label>
                    <input type="tel" name="phone" value={formData.phone} onChange={handleChange} />
                </div>

                <div className="form-group">
                    <label>Address:</label>
                    <input type="text" name="address" value={formData.address} onChange={handleChange} />
                </div>

                <div className="form-group">
                    <label>Preferred Position:</label>
                    <select name="position" value={formData.position} onChange={handleChange}>
                        <option value="web_developer">Web Developer</option>
                        <option value="graphic_designer">Graphic Designer</option>
                        <option value="marketing_specialist">Marketing Specialist</option>
                    </select>
                </div>

                <div className="form-group">
                    <label>Gender:</label>
                    <label><input type="radio" name="gender" value="male" checked={formData.gender === "male"} onChange={handleChange} /> Male</label>
                    <label><input type="radio" name="gender" value="female" checked={formData.gender === "female"} onChange={handleChange} /> Female</label>
                </div>

                <div className="form-group">
                    <label>Additional Options:</label>
                    <label><input type="checkbox" name="experience" checked={formData.experience} onChange={handleChange} /> I have prior experience</label>
                    <label><input type="checkbox" name="weekends" checked={formData.weekends} onChange={handleChange} /> I can work weekends</label>
                </div>

                <div className="form-group">
                    <label>Comments:</label>
                    <textarea name="comments" rows="4" value={formData.comments} onChange={handleChange}></textarea>
                </div>

                <div className="form-group">
                    <input type="submit" value="Submit" />
                </div>
            </form>
        </div>
    );
};

export default JobApplication;
