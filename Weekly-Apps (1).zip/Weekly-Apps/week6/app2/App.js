
import './App.css';
import LoginForm from './LoginForm';

function App() {
  return (
    <div className="App">
     <LoginForm />
    </div>
  );
}

export default App;
