import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const LoginForm = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [loginAttempted, setLoginAttempted] = useState(false); // Track login attempts

    const users = [
        { em: '625@utas.edu.om', pas: 'utas625' },
        { em: '626@utas.edu.om', pas: 'utas626' }
    ];

    useEffect(() => {
        if (loginAttempted) {
            alert(isLoggedIn ? 'You Are Logged In' : 'Invalid Email or Password. Please try again');
            setLoginAttempted(false); // Reset after showing alert
        }
    }, [isLoggedIn, loginAttempted]);

    const handleReset = () => {
        setEmail('');
        setPassword('');
    };

    const handleLogin = () => {
        const foundUser = users.find((user) => user.em === email && user.pas === password);
        setIsLoggedIn(!!foundUser); // converts foundUser into a boolean true or false
        setLoginAttempted(true);
    };

    return (
        <div className="container mt-5">
            <h2 className="text-center mb-4">Login Form</h2>
            <form className="p-4 border rounded shadow-sm bg-light">
                <div className="mb-3">
                    <label className="form-label">Email</label>
                    <input type="email" className="form-control" value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div className="mb-3">
                    <label className="form-label">Password</label>
                    <input type="password" className="form-control" value={password} onChange={(e) => setPassword(e.target.value)} />
                </div>
                <div className="d-flex justify-content-center">
                    <button type="button" className="btn btn-primary m-2" onClick={handleLogin}>Login</button>
                    <button type="button" className="btn btn-secondary m-2" onClick={handleReset}>Reset</button>
                </div>
            </form>
        </div>
    );
}

export default LoginForm;
