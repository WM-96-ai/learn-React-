import 'bootstrap/dist/css/bootstrap.min.css';


const Mid = () => {
    const myDate = new Date().toLocaleString('en-US', { month: 'short' });
    const myCode = 'ccSe3001';

    return (
        <>
            <div id='mydiv' className='container-fluid bg-primary p-3'>
                <div className='d-flex justify-content-center align-items-center'>
                <span className='display-1 text-light'>{myDate}</span>
                </div>
                <h1 className='text-center text-warning'> {myCode.substring(0,4).toUpperCase()}</h1>
                
            </div>

        </>
    )
}

export default Mid;