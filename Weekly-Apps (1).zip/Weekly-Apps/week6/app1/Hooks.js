import 'bootstrap/dist/css/bootstrap.min.css';
import React, {useState} from 'react';

const Hooks=()=>{
const [semester,setSemester] = useState('Spring 2024-2025');
const [major,setMajor] = useState('Software Engineering');

    return(
        <>
        <div className='container-fluid d-flex flex-column justify-content-center align-items-center bg-primary text-light'>
             <p className='fs-3'>{semester}</p>
             <p className='fs-4'>{major}</p>
        </div>
        
        </>
    )
}

export default Hooks;