import Mid from "./Mid";
import Image from "./Image";
import FunProps from "./FunProps";
import Hooks from "./Hooks";

function App() {
  return (
   <>
   <Mid />
   <FunProps name="Mohamed Al-AJmi" course="Advanced Web Technologies" section="A-1" />
   <Image />
   <Hooks />
   </>
  );
}

export default App;
