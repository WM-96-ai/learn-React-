import 'bootstrap/dist/css/bootstrap.min.css';
import Logo from './cars.jpeg';



const Image = () => {


    return (
        <>
            <div className='container-fluid bg-warning d-flex justify-content-start'>
                <img src={Logo} className='rounded-circle p-3' alt='Logo' style={{height:'10%', width:'10%', objectFit:'cover'}}/>
            </div>
        </>
    )
}

export default Image;