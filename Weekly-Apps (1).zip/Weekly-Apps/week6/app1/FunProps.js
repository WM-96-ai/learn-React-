import 'bootstrap/dist/css/bootstrap.min.css';


const FunProps = ({ name, course, section }) => {


    return (
        <>
            <div className='container-fluid p-3 text-dark text-end'>
                <h2>my Details</h2>
                <p><strong>Name: </strong>{name}</p>
                <p><strong>Course: </strong>{course}</p>
                <p><strong>Section: </strong>{section}</p>

            </div>

        </>
    )
}

export default FunProps;