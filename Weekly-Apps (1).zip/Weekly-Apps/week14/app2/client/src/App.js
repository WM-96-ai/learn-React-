import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Stock from './Stock';
import AddItems from './AddItems';
import UpdateStock from './UpdateStock';
import Orders from './Orders';

const App = () => {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Stock />} />
                <Route path="/add-item" element={<AddItems />} />
                <Route path="/update-item" element={<UpdateStock />} />
                <Route path="/orders" element={<Orders />} />
            </Routes>
        </Router>
    );
};

export default App;
