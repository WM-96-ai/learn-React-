import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const AddItems = () => {
  const [formData, setFormData] = useState({
    batchNo: '',
    itemNo: '',
    itemName: '',
    description: '',
    quantity: '',
    expiryDate: '',
    unitPrice: '',
  });

  const [successMessage, setSuccessMessage] = useState(null);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:3003/stock/add', formData);
      setSuccessMessage('Item added successfully!');
      setTimeout(() => navigate('/'), 1500);
    } catch (error) {
      setError('Failed to add item. Please try again.');
    }
  };

  return (
    <div className="container mt-4">
      <h1 className="text-center">Add New Stock Item</h1>
      {successMessage && <div className="alert alert-success">{successMessage}</div>}
      {error && <div className="alert alert-danger">{error}</div>}
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label>Batch Number</label>
          <input type="text" name="batchNo" className="form-control" value={formData.batchNo} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Item Number</label>
          <input type="text" name="itemNo" className="form-control" value={formData.itemNo} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Item Name</label>
          <input type="text" name="itemName" className="form-control" value={formData.itemName} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Description</label>
          <textarea name="description" className="form-control" value={formData.description} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Quantity</label>
          <input type="number" name="quantity" className="form-control" value={formData.quantity} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Expiry Date</label>
          <input type="date" name="expiryDate" className="form-control" value={formData.expiryDate} onChange={handleChange} required />
        </div>
        <div className="mb-3">
          <label>Unit Price</label>
          <input type="number" name="unitPrice" className="form-control" value={formData.unitPrice} onChange={handleChange} required />
        </div>
        <button type="submit" className="btn btn-primary w-100">Add Item</button>
      </form>
    </div>
  );
};

export default AddItems;
