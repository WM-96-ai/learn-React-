import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const Stock = () => {
  const [stock, setStock] = useState([]);
  const [orderTable, setOrderTable] = useState([]);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);

  // Fetch stock items on component mount
  useEffect(() => {
    const fetchStock = async () => {
      try {
        const response = await axios.get('http://localhost:3003/stock');
        setStock(response.data);
      } catch (error) {
        console.error('Error fetching stock:', error);
        setError('Failed to load stock items.');
      }
    };

    fetchStock();
  }, []);

  // Add an item to the orders table
  const handleAddToOrder = (item) => {
    // Avoid duplicate entries in the order table
    if (!orderTable.some((order) => order.itemNo === item.itemNo)) {
      setOrderTable([...orderTable, { ...item, orderQuantity: 1 }]);
    }
  };

  // Update order quantity
  const handleOrderQuantityChange = (index, newQuantity) => {
    const updatedOrderTable = [...orderTable];
    updatedOrderTable[index].orderQuantity = newQuantity;
    setOrderTable(updatedOrderTable);
  };

  // Save the order
  const handleSaveOrder = async () => {
    try {
        // Prompt for customer phone number
        const customerPhone = prompt("Enter Customer Phone Number:");

        if (!customerPhone) {
            setError('Customer phone number is required.');
            return;
        }

        // Prepare order data
        const ordersToSave = orderTable.map((order) => ({
            itemNo: order.itemNo,
            itemName: order.itemName,
            batchNo: order.batchNo,
            quantity: order.orderQuantity,
            unitPrice: order.unitPrice,
            phone: customerPhone,
        }));

        // Send order data to the server
        for (const order of ordersToSave) {
            await axios.post('http://localhost:3003/orders/add', order);
        }

        // Refresh stock data
        const response = await axios.get('http://localhost:3003/stock');
        setStock(response.data);

        // Clear order table and display success message
        setOrderTable([]);
        setSuccessMessage('Order saved successfully!');
    } catch (error) {
        console.error('Error saving order:', error);
        setError('Failed to save order.');
    }
};

  // Helper function to check if an item is expired
  const isExpired = (expiryDate) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    // Set time to 0:00:00 to compare dates without time
    today.setHours(0, 0, 0, 0);
    expiry.setHours(0, 0, 0, 0);
    return expiry <= today;
  };

  return (
    <div className="container mt-4">
      <h1 className="text-center mb-4">Pharmacy System</h1>

      {error && <div className="alert alert-danger text-center">{error}</div>}
      {successMessage && <div className="alert alert-success text-center">{successMessage}</div>}

      {/* Stock Table */}
      <h2 className="mt-4">Pharmacy Stock</h2>
      <div className="table-responsive">
        <table className="table table-bordered table-hover">
          <thead className="table-primary">
            <tr>
              <th>Batch No</th>
              <th>Item No</th>
              <th>Item Name</th>
              <th>Quantity</th>
              <th>Expiry Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {stock.map((item) => (
              <tr key={item.itemNo}>
                <td>{item.batchNo}</td>
                <td>{item.itemNo}</td>
                <td>{item.itemName}</td>
                <td>{item.quantity}</td>
                <td style={isExpired(item.expiryDate) ? { color: 'red', fontWeight: 'bold' } : {}}>
                  {new Date(item.expiryDate).toLocaleDateString()}
                </td>
                <td>
                  <button
                    className="btn btn-success btn-sm"
                    onClick={() => handleAddToOrder(item)}
                    disabled={item.quantity <= 0 || isExpired(item.expiryDate)}
                  >
                    Add to Order
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Order Table */}
      <h2 className="mt-4">Orders</h2>
      {orderTable.length > 0 ? (
        <div className="table-responsive">
          <table className="table table-bordered table-hover">
            <thead className="table-secondary">
              <tr>
                <th>Item No</th>
                <th>Item Name</th>
                <th>Batch No</th>
                <th>Quantity to Order</th>
              </tr>
            </thead>
            <tbody>
              {orderTable.map((order, index) => (
                <tr key={order.itemNo}>
                  <td>{order.itemNo}</td>
                  <td>{order.itemName}</td>
                  <td>{order.batchNo}</td>
                  <td>
                    <input
                      type="number"
                      className="form-control form-control-sm"
                      min="1"
                      max={stock.find((item) => item.itemNo === order.itemNo)?.quantity || 1}
                      value={order.orderQuantity}
                      onChange={(e) =>
                        handleOrderQuantityChange(index, parseInt(e.target.value, 10) || 1)
                      }
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="btn btn-primary" onClick={handleSaveOrder}>
            Save Order
          </button>
        </div>
      ) : (
        <p>No items in the order. Add items from the stock above.</p>
      )}
    </div>
  );
};

export default Stock;
