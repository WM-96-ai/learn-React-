import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get('http://localhost:3003/orders');
        setOrders(response.data);
      } catch (error) {
        setError('Failed to fetch orders. Please try again.');
      }
    };

    fetchOrders();
  }, []);

  return (
    <div className="container mt-4">
      <h1 className="text-center">Orders</h1>
      {error && <div className="alert alert-danger">{error}</div>}
      <div className="table-responsive">
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Item Name</th>
              <th>Item Number</th>
              <th>Quantity</th>
              <th>Customer Phone</th>
              <th>Unit Price</th>
              <th>Purchase Date</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order._id}>
                <td>{order.itemName}</td>
                <td>{order.itemNo}</td>
                <td>{order.quantity}</td>
                <td>{order.phone}</td>
                <td>${order.unitPrice}</td>
                <td>{new Date(order.purchaseDate).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Orders;
