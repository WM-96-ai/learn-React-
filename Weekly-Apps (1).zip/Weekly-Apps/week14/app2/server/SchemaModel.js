import mongoose from 'mongoose';

const myDB = 'PharmacyDB';

mongoose.connect(`mongodb+srv://admin:admin123@cluster0.555tvu8.mongodb.net/${myDB}`);

// Define Schema


const stockSchema = new mongoose.Schema({
    batchNo: { type: String, required: true },
    itemNo: { type: String, required: true },
    itemName: { type: String, required: true },
    description: { type: String, required: true },
    quantity: { type: Number, required: true },
    expiryDate: { type: Date, required: true },
    unitPrice: { type: Number, required: true },
});

const orderSchema = new mongoose.Schema({
    itemNo: { type: String, required: true },
    itemName: { type: String, required: true },
    quantity: { type: Number, required: true },
    phone: { type: String, required: true },
    unitPrice: { type: Number, required: true },
    purchaseDate: { type: Date, default: Date.now },
});

const ItemsModel = mongoose.model('items_collections', stockSchema);
const OrdersModel = mongoose.model('orders_collections', orderSchema);

export { ItemsModel, OrdersModel, myDB };
