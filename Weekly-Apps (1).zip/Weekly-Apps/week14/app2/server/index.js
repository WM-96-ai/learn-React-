import express from 'express';
import cors from 'cors';

import { ItemsModel, OrdersModel } from './SchemaModel.js';


const app = express();
const PORT = 3003;

// Middleware
app.use(express.json());
app.use(cors());


// Routes

// StockItem CRUD operations
app.get('/stock', async (req, res) => {
    try {
        const items = await ItemsModel.find();
        res.json(items);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

app.post('/stock/add', async (req, res) => {
    try {
        const { batchNo, itemNo, itemName, description, quantity, expiryDate, unitPrice } = req.body;
        const newItem = await ItemsModel.create({ batchNo, itemNo, itemName, description, quantity, expiryDate, unitPrice });
        res.status(201).json(newItem);
    } catch (error) {
        res.status(500).json({ message: 'Error adding stock item' });
    }
});

app.put('/stock/update/:id', async (req, res) => {
    try {
        const updatedItem = await ItemsModel.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedItem);
    } catch (error) {
        res.status(500).json({ message: 'Error updating stock item' });
    }
});

app.delete('/stock/delete/:id', async (req, res) => {
    try {
        const deletedItem = await ItemsModel.findByIdAndDelete(req.params.id);
        res.json({ message: 'Stock item deleted', deletedItem });
    } catch (error) {
        res.status(500).json({ message: 'Error deleting stock item' });
    }
});

// Order CRUD operations
app.get('/orders', async (req, res) => {
    try {
        const orders = await OrdersModel.find();
        res.json(orders);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

app.post('/orders/add', async (req, res) => {
    try {
        const { itemNo, itemName, batchNo, quantity, phone, unitPrice } = req.body;

        // Find the stock item
        const stockItem = await ItemsModel.findOne({ itemNo });

        if (!stockItem) {
            return res.status(404).json({ message: 'Stock item not found' });
        }

        if (stockItem.quantity < quantity) {
            return res.status(400).json({ message: 'Insufficient stock quantity' });
        }

        // Subtract quantity from stock
        stockItem.quantity -= quantity;
        await stockItem.save();

        // Create new order
        const newOrder = await OrdersModel.create({
            itemNo,
            itemName,
            batchNo,
            quantity,
            phone,
            unitPrice,
            purchaseDate: new Date(),
        });

        res.status(201).json(newOrder);
    } catch (error) {
        console.error('Error creating order:', error);
        res.status(500).json({ message: 'Error creating order' });
    }
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
