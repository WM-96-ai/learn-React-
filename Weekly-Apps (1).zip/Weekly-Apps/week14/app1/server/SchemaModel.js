import mongoose from 'mongoose';
import bcrypt from 'bcrypt';
import dotenv from 'dotenv';
dotenv.config();

const myDB = 'PharmacyDB';

mongoose.connect(process.env.MONGO_URI);

// Define Schema

const userSchema = mongoose.Schema({
    fullName: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    contactNo: { type: String, required: true },
    admin: { type: String, required: true, default: 'N' },
    password: { type: String, required: true },
    resetPasswordToken: String,
    resetPasswordExpires: Date,
});

userSchema.pre('save', async function (next) {
    if (this.isModified('password')) {
        this.password = await bcrypt.hash(this.password, 10);
    }
    next();
});

const itemSchema = new mongoose.Schema({
    batchNo: { type: String, required: true },
    itemNo: { type: String, required: true },
    itemName: { type: String, required: true },
    description: { type: String, required: true },
    quantity: { type: Number, required: true },
    expiryDate: { type: Date, required: true },
    unitPrice: { type: Number, required: true },
});

const orderSchema = new mongoose.Schema({
    itemNo: { type: String, required: true },
    itemName: { type: String, required: true },
    quantity: { type: Number, required: true },
    phone: { type: String, required: true },
    unitPrice: { type: Number, required: true },
    purchaseDate: { type: Date, default: Date.now },
});

const itemModel = mongoose.model('items_collections', itemSchema);
const orderModel = mongoose.model('orders_collections', orderSchema);
const userModel = mongoose.model('users_collections', userSchema);

export { userModel, itemModel, orderModel, myDB };
