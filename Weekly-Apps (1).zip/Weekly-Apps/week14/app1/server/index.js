import express, { json } from 'express';
import cors from 'cors';
import { userModel, itemModel, orderModel, myDB } from './SchemaModel.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcrypt';
import crypto from 'crypto';
import nodemailer from 'nodemailer';


const myApp = express();
const PORT = 3003;

myApp.use(express.json());
myApp.use(cors());


const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.RESET_EMAIL_USER,
    pass: process.env.RESET_EMAIL_PASS,
  },
});

myApp.post('/register', async (req, res) => {
    try {
        const { fullName, email, contactNo, password } = req.body;

        // Check if the required fields are provided
        if (!fullName || !email || !contactNo || !password) {
            return res.status(400).json({ error: "Missing required fields" });
        }

        // Check if the user already exists
        const existingUser = await userModel.findOne({ email });
        if (existingUser) {
            return res.status(409).json({ error: "User already exists with this email" });
        }

        // Create and save the new user
        const newUser = new userModel({ fullName, email, contactNo, password });
        await newUser.save();
        res.status(201).json({ message: 'User registered successfully' });

        //res.status(201).json({ message: 'User registered successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error registering user' });
    }
});

myApp.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        console.log('Login request received:', { email });

        if (!email || !password) {
            return res.status(400).json({ error: 'Email and password are required' });
        }

        const user = await userModel.findOne({ email });
        if (!user) {
            console.log('User not found:', email);
            return res.status(404).json({ error: 'User not found' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            console.log('Password mismatch for user:', email);
            return res.status(400).json({ error: 'Invalid credentials' });
        }

        if (!process.env.JWT_SECRET) throw new Error("JWT_SECRET not defined");
        const token = jwt.sign({ id: user._id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });


        console.log('Login successful for user:', email);
        res.json({
            token,
            user: {
                id: user._id,
                fullName: user.fullName,
                email: user.email,
                contactNo: user.contactNo,
            },
        });
    } catch (err) {
        console.error('Error during login:', err);
        res.status(500).json({ error: 'Login failed' });
    }
});

myApp.get('/profile', async (req, res) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader) return res.status(401).json({ error: 'No token provided' });

        const token = authHeader.split(' ')[1];
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'default_secret');

        const user = await userModel.findById(decoded.id).select('-password');
        if (!user) return res.status(404).json({ error: 'User not found' });

        res.json(user);
    } catch (error) {
        console.error('Error fetching profile:', error);
        res.status(500).json({ error: 'Failed to fetch profile' });
    }
});


myApp.put('/profile', async (req, res) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader) return res.status(401).json({ error: 'No token provided' });

        const token = authHeader.split(' ')[1];
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'default_secret');

        const { fullName, email, contactNo } = req.body;

        const updatedUser = await userModel.findByIdAndUpdate(
            decoded.id,
            { fullName, email, contactNo },
            { new: true }
        ).select('-password');
        if (!updatedUser) return res.status(404).json({ error: 'User not found' });

        res.json(updatedUser);
    } catch (error) {
        console.error('Error updating profile:', error);
        res.status(500).json({ error: 'Failed to update profile' });
    }
});


myApp.post('/change-password', async (req, res) => {
    try {
        const authHeader = req.headers.authorization;
        if (!authHeader) return res.status(401).json({ error: 'No token provided' });

        const token = authHeader.split(' ')[1];
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'default_secret');

        const { oldPassword, newPassword } = req.body;

        const user = await userModel.findById(decoded.id);
        if (!user) return res.status(404).json({ error: 'User not found' });

        const isMatch = await bcrypt.compare(oldPassword, user.password);
        if (!isMatch) return res.status(400).json({ error: 'Old password is incorrect' });

        user.password = newPassword;
        await user.save();

        res.json({ message: 'Password changed successfully' });
    } catch (error) {
        console.error('Error changing password:', error);
        res.status(500).json({ error: 'Failed to change password' });
    }
});

myApp.post('/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    const user = await userModel.findOne({ email });
    if (!user) return res.status(404).json({ error: 'Email not found' });

    const resetToken = crypto.randomBytes(32).toString('hex');
    const hashedToken = crypto.createHash('sha256').update(resetToken).digest('hex');
    const expiryTime = Date.now() + 15 * 60 * 1000; // 15 min

    user.resetPasswordToken = hashedToken;
    user.resetPasswordExpires = expiryTime;
    await user.save();

    const resetUrl = `http://localhost:3000/reset-password?token=${resetToken}&email=${email}`;

    const mailOptions = {
      from: '"Pharmacy App" <no-reply@pharmacy.com>',
      to: email,
      subject: 'Password Reset Link',
      html: `
        <p>You requested a password reset.</p>
        <p><a href="${resetUrl}">Click here to reset your password</a></p>
        <p>This link expires in 15 minutes.</p>
      `,
    };

    await transporter.sendMail(mailOptions);

    res.json({ message: 'Reset link sent to your email.' });
  } catch (error) {
    console.error('Error in forgot-password:', error);
    res.status(500).json({ error: 'Failed to send reset email' });
  }
});







myApp.post('/reset-password', async (req, res) => {
  try {
    const { token, email, newPassword } = req.body;

    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');

    const user = await userModel.findOne({
      email,
      resetPasswordToken: hashedToken,
      resetPasswordExpires: { $gt: Date.now() },
    });

    if (!user) {
      return res.status(400).json({ error: 'Invalid or expired token' });
    }

    user.password = newPassword;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;

    await user.save();

    res.json({ message: 'Password reset successful' });
  } catch (error) {
    console.error('Error in reset-password:', error);
    res.status(500).json({ error: 'Failed to reset password' });
  }
});

myApp.get('/items', async (req, res) => {
    try {
        const items = await itemModel.find();
        res.json(items);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

myApp.post('/items/add', async (req, res) => {
    try {
        const { batchNo, itemNo, itemName, description, quantity, expiryDate, unitPrice } = req.body;
        const newItem = await itemModel.create({ batchNo, itemNo, itemName, description, quantity, expiryDate, unitPrice });
        res.status(201).json(newItem);
    } catch (error) {
        res.status(500).json({ message: 'Error adding stock item' });
    }
});

myApp.put('/items/update/:id', async (req, res) => {
    try {
        const updatedItem = await itemModel.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedItem);
    } catch (error) {
        res.status(500).json({ message: 'Error updating stock item' });
    }
});

myApp.delete('/items/delete/:id', async (req, res) => {
    try {
        const deletedItem = await itemModel.findByIdAndDelete(req.params.id);
        res.json({ message: 'Stock item deleted', deletedItem });
    } catch (error) {
        res.status(500).json({ message: 'Error deleting stock item' });
    }
});

// Order CRUD operations
myApp.get('/orders', async (req, res) => {
    try {
        const orders = await orderModel.find();
        res.json(orders);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

myApp.post('/orders/add', async (req, res) => {
    try {
        const { itemNo, itemName, batchNo, quantity, phone, unitPrice } = req.body;

        // Find the stock item
        const stockItem = await itemModel.findOne({ itemNo });

        if (!stockItem) {
            return res.status(404).json({ message: 'Stock item not found' });
        }

        if (stockItem.quantity < quantity) {
            return res.status(400).json({ message: 'Insufficient stock quantity' });
        }

        // Subtract quantity from stock
        stockItem.quantity -= quantity;
        await stockItem.save();

        // Create new order
        const newOrder = await orderModel.create({
            itemNo,
            itemName,
            batchNo,
            quantity,
            phone,
            unitPrice,
            purchaseDate: new Date(),
        });

        res.status(201).json(newOrder);
    } catch (error) {
        console.error('Error creating order:', error);
        res.status(500).json({ message: 'Error creating order' });
    }
});



myApp.listen(PORT, () => {
    console.log('You Are Connected');
    console.log(`You Server running on http://localhost:${PORT}`);
    console.log(`You are connected to ${myDB} database`);
})