import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Register from './Register';
import Login from './Login';
import ForgotPassword from './ForgotPassword';

import NewHome from './NewHome';
import EditProfile from './EditProfile';
import ChangePassword from './ChangePassword';
import Stock from './Stock';
import AddItems from './AddItems';
import Orders from './Orders';
import UpdateStock from './UpdateStock';
import DashboardLayout from './DashboardLayout';
import Home from './Home';
import ProtectedRoute from './ProtectedRoute';
import ResetPassword from './ResetPassword';
import Expired from './Expired';
import LowStock from './LowStock';
import ManageItems from './ManageItems';

const App = () => {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />

        {/* Protected Routes */}
        <Route
          element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/NewHome" element={<NewHome />} />
          <Route path="/edit-profile" element={<EditProfile />} />
          <Route path="/change-password" element={<ChangePassword />} />
          <Route path="/stock" element={<Stock />} />
          <Route path="/add-item" element={<AddItems />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/update-stock" element={<UpdateStock />} />
          <Route path="/expired" element={<Expired />} />
          <Route path="/low-stock" element={<LowStock />} />
          <Route path="/manage-items" element={<ManageItems />} />
        </Route>

        {/* Fallback Route */}
        <Route path="*" element={<Home />} />
      </Routes>
    </Router>
  );
};

export default App;
