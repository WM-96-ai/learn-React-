import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const EditProfile = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    contactNo: '',
  });

  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:3003/profile', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setFormData({
          fullName: res.data.fullName,
          email: res.data.email,
          contactNo: res.data.contactNo,
        });
      } catch (err) {
        alert('Error fetching user data');
      }
    };

    fetchUserData();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        'http://localhost:3003/profile',
        formData,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      navigate('/NewHome'); // Redirect after update
    } catch (err) {
      alert('Error updating profile');
    }
  };

  const handleCancel = () => {
    navigate('/NewHome'); // Redirect without update
  };

  return (
    <div className="container mt-4">
      <h2 className="text-center">Edit Profile</h2>
      <form onSubmit={handleSubmit} className="card p-4 shadow-sm">
        <div className="mb-3">
          <label>Full Name</label>
          <input
            type="text"
            name="fullName"
            className="form-control"
            value={formData.fullName}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label>Email</label>
          <input
            type="email"
            name="email"
            className="form-control"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="mb-3">
          <label>Contact Number</label>
          <input
            type="text"
            name="contactNo"
            className="form-control"
            value={formData.contactNo}
            onChange={handleChange}
            required
          />
        </div>
        <div className="d-flex justify-content-between">
          <button type="submit" className="btn btn-primary">Update Profile</button>
          <button type="button" className="btn btn-secondary" onClick={handleCancel}>Cancel</button>
        </div>
      </form>
    </div>
  );
};

export default EditProfile;
