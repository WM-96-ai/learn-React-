import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const ManageItems = () => {
    const [items, setItems] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;
    const navigate = useNavigate();
    const token = localStorage.getItem('token');

    useEffect(() => {
        fetchItems();
    }, []);

    const fetchItems = async () => {
        try {
            const res = await axios.get('http://localhost:3003/items');
            setItems(res.data);
        } catch (err) {
            console.error('Failed to fetch items');
        }
    };

    const handleDelete = async (id) => {
        if (!window.confirm('Are you sure you want to delete this item?')) return;
        try {
            await axios.delete(`http://localhost:3003/items/delete/${id}`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            fetchItems();
        } catch (err) {
            console.error('Failed to delete item');
        }
    };

    const handleEdit = (item) => {
        navigate('/update-stock', { state: { item } });
    };

    const handleAdd = () => {
        navigate('/add-item');
    };

    const filteredItems = items.filter(item => {
        const term = searchTerm.toLowerCase();
        return (
            item.itemName.toLowerCase().includes(term) ||
            item.itemNo.toLowerCase().includes(term) ||
            item.batchNo.toLowerCase().includes(term)
        );
    });

    const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
    const paginated = filteredItems.slice(
        (currentPage - 1) * itemsPerPage,
        currentPage * itemsPerPage
    );

    return (
        <div className="container mt-4">
            <div className="d-flex justify-content-between align-items-center mb-3">
                <h1 className="text-primary">Manage Items</h1>
                <button className="btn btn-success" onClick={handleAdd}>Add New Item</button>
            </div>

            <input
                type="text"
                className="form-control mb-3"
                placeholder="Search by name, number or batch"
                value={searchTerm}
                onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setCurrentPage(1);
                }}
            />

            <div className="table-responsive">
                <table className="table table-bordered table-hover">
                    <thead className="table-info">
                        <tr>
                            <th>Batch No</th>
                            <th>Item No</th>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Expiry Date</th>
                            <th>Unit Price</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {paginated.map(item => (
                            <tr key={item._id}>
                                <td>{item.batchNo}</td>
                                <td>{item.itemNo}</td>
                                <td>{item.itemName}</td>
                                <td>{item.quantity}</td>
                                <td>{new Date(item.expiryDate).toLocaleDateString()}</td>
                                <td>${item.unitPrice.toFixed(2)}</td>
                                <td>
                                    <button className="btn btn-warning btn-sm me-2" onClick={() => handleEdit(item)}>Edit</button>
                                    <button className="btn btn-danger btn-sm" onClick={() => handleDelete(item._id)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Pagination */}
            <nav className="mt-3 d-flex justify-content-center">
                <ul className="pagination">
                    <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                        <button className="page-link" onClick={() => setCurrentPage(currentPage - 1)}>Previous</button>
                    </li>
                    {Array.from({ length: totalPages }, (_, index) => (
                        <li key={index} className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}>
                            <button className="page-link" onClick={() => setCurrentPage(index + 1)}>{index + 1}</button>
                        </li>
                    ))}
                    <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                        <button className="page-link" onClick={() => setCurrentPage(currentPage + 1)}>Next</button>
                    </li>
                </ul>
            </nav>
        </div>
    );
};

export default ManageItems;
