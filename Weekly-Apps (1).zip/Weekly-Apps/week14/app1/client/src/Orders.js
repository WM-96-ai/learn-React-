import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await axios.get('http://localhost:3003/orders', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setOrders(response.data);
        setFilteredOrders(response.data);
      } catch (error) {
        setError('Failed to fetch orders. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchOrders();
  }, [token]);

  useEffect(() => {
    const term = searchTerm.toLowerCase();
    const filtered = orders.filter(
      (order) =>
        order.itemName.toLowerCase().includes(term) ||
        order.itemNo.toLowerCase().includes(term) ||
        order.phone.includes(term)
    );
    setFilteredOrders(filtered);
    setCurrentPage(1); // Reset to first page on search
  }, [searchTerm, orders]);

  // Pagination logic
  const paginatedOrders = filteredOrders.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );
  const totalPages = Math.ceil(filteredOrders.length / pageSize);

  return (
    <div className="container mt-4">
      <h1 className="text-center">Orders</h1>

      {loading && <div className="alert alert-info text-center">Loading orders...</div>}
      {error && <div className="alert alert-danger text-center">{error}</div>}

      <div className="mb-3">
        <input
          type="text"
          className="form-control"
          placeholder="Search by item name, number or phone"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {paginatedOrders.length > 0 ? (
        <>
          <div className="table-responsive">
            <table className="table table-striped table-bordered">
              <thead className="table-secondary">
                <tr>
                  <th>Item Name</th>
                  <th>Item Number</th>
                  <th>Quantity</th>
                  <th>Customer Phone</th>
                  <th>Unit Price</th>
                  <th>Purchase Date</th>
                </tr>
              </thead>
              <tbody>
                {paginatedOrders.map((order) => (
                  <tr key={order._id}>
                    <td>{order.itemName}</td>
                    <td>{order.itemNo}</td>
                    <td>{order.quantity}</td>
                    <td>{order.phone}</td>
                    <td>${order.unitPrice.toFixed(2)}</td>
                    <td>{new Date(order.purchaseDate).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          <nav className="mt-3 d-flex justify-content-center">
            <ul className="pagination">
              <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                <button className="page-link" onClick={() => setCurrentPage(currentPage - 1)}>
                  Previous
                </button>
              </li>
              {Array.from({ length: totalPages }, (_, index) => (
                <li
                  key={index + 1}
                  className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}
                >
                  <button className="page-link" onClick={() => setCurrentPage(index + 1)}>
                    {index + 1}
                  </button>
                </li>
              ))}
              <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                <button className="page-link" onClick={() => setCurrentPage(currentPage + 1)}>
                  Next
                </button>
              </li>
            </ul>
          </nav>
        </>
      ) : (
        !loading && <div className="alert alert-warning text-center">No orders found.</div>
      )}
    </div>
  );
};

export default Orders;
