import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const Stock = () => {
  const [stock, setStock] = useState([]);
  const [orderTable, setOrderTable] = useState([]);
  const [customerPhone, setCustomerPhone] = useState('');
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showPhoneModal, setShowPhoneModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const itemsPerPage = 10;
  const token = localStorage.getItem('token');

  const isExpired = (expiryDate) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    today.setHours(0, 0, 0, 0);
    expiry.setHours(0, 0, 0, 0);
    return expiry <= today;
  };

  const fetchStock = useCallback(async () => {
    try {
      const response = await axios.get('http://localhost:3003/items');
      const nonExpiredItems = response.data.filter(item => !isExpired(item.expiryDate));
      setStock(nonExpiredItems);
    } catch (error) {
      console.error('Error fetching stock:', error);
      setError('Failed to load stock items.');
    }
  }, []);

  useEffect(() => {
    fetchStock();
  }, [fetchStock]);


  const handleAddToOrder = (item) => {
    if (!orderTable.some((order) => order.itemNo === item.itemNo)) {
      setOrderTable([...orderTable, { ...item, orderQuantity: 1 }]);
    }
  };

  const handleOrderQuantityChange = (index, newQuantity) => {
    const updatedOrderTable = [...orderTable];
    updatedOrderTable[index].orderQuantity = newQuantity;
    setOrderTable(updatedOrderTable);
  };

  const handleRemoveOrderItem = (itemNo) => {
    setOrderTable(orderTable.filter(order => order.itemNo !== itemNo));
  };

  const handleSaveOrder = () => {
    setShowPhoneModal(true);
  };

  const handlePhoneSubmit = async () => {
    if (!customerPhone.trim()) {
      setError('Customer phone number is required.');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      setSuccessMessage(null);

      const ordersToSave = orderTable.map((order) => ({
        itemNo: order.itemNo,
        itemName: order.itemName,
        batchNo: order.batchNo,
        quantity: order.orderQuantity,
        unitPrice: order.unitPrice,
        phone: customerPhone,
      }));

      for (const order of ordersToSave) {
        await axios.post('http://localhost:3003/orders/add', order, {
          headers: { Authorization: `Bearer ${token}` },
        });
      }

      setSuccessMessage('Order saved successfully!');
      setOrderTable([]);
      setCustomerPhone('');
      setShowPhoneModal(false);
      fetchStock();
    } catch (error) {
      console.error('Error saving order:', error);
      setError('Failed to save order.');
    } finally {
      setLoading(false);
    }
  };

  const filteredStock = stock.filter(item => {
    const term = searchTerm.toLowerCase();
    return (
      item.itemName.toLowerCase().includes(term) ||
      item.itemNo.toLowerCase().includes(term) ||
      item.batchNo.toLowerCase().includes(term)
    );
  });

  const totalPages = Math.ceil(filteredStock.length / itemsPerPage);
  const currentStock = filteredStock.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="container mt-4">
      <h1 className="text-center mb-4">Pharmacy Stock</h1>

      {error && <div className="alert alert-danger text-center">{error}</div>}
      {successMessage && <div className="alert alert-success text-center">{successMessage}</div>}

      <input
        type="text"
        className="form-control mb-3"
        placeholder="Search by item name, number or batch number"
        value={searchTerm}
        onChange={(e) => {
          setSearchTerm(e.target.value);
          setCurrentPage(1);
        }}
      />

      {/* Stock Table */}
      <div className="table-responsive">
        <table className="table table-bordered table-hover">
          <thead className="table-primary">
            <tr>
              <th>Batch No</th>
              <th>Item No</th>
              <th>Item Name</th>
              <th>Quantity</th>
              <th>Expiry Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {currentStock.map((item) => (
              <tr key={item.itemNo}>
                <td>{item.batchNo}</td>
                <td>{item.itemNo}</td>
                <td>{item.itemName}</td>
                <td>{item.quantity}</td>
                <td>{new Date(item.expiryDate).toLocaleDateString()}</td>
                <td>
                  <button
                    className="btn btn-success btn-sm"
                    onClick={() => handleAddToOrder(item)}
                    disabled={item.quantity <= 0}
                  >
                    Add to Order
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <nav className="mt-3 d-flex justify-content-center">
        <ul className="pagination">
          <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
            <button className="page-link" onClick={() => setCurrentPage(currentPage - 1)}>Previous</button>
          </li>
          {Array.from({ length: totalPages }, (_, index) => (
            <li key={index} className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}>
              <button className="page-link" onClick={() => setCurrentPage(index + 1)}>{index + 1}</button>
            </li>
          ))}
          <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
            <button className="page-link" onClick={() => setCurrentPage(currentPage + 1)}>Next</button>
          </li>
        </ul>
      </nav>

      {/* Order Table */}
      {orderTable.length > 0 && (
        <div className="mt-5">
          <h2>Orders</h2>
          <div className="table-responsive">
            <table className="table table-bordered">
              <thead className="table-secondary">
                <tr>
                  <th>Item No</th>
                  <th>Item Name</th>
                  <th>Batch No</th>
                  <th>Quantity to Order</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {orderTable.map((order, index) => (
                  <tr key={order.itemNo}>
                    <td>{order.itemNo}</td>
                    <td>{order.itemName}</td>
                    <td>{order.batchNo}</td>
                    <td>
                      <input
                        type="number"
                        className="form-control form-control-sm"
                        min="1"
                        max={stock.find((item) => item.itemNo === order.itemNo)?.quantity || 1}
                        value={order.orderQuantity}
                        onChange={(e) =>
                          handleOrderQuantityChange(index, parseInt(e.target.value, 10) || 1)
                        }
                      />
                    </td>
                    <td>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleRemoveOrderItem(order.itemNo)}
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button className="btn btn-primary" onClick={handleSaveOrder} disabled={loading}>
              {loading ? 'Processing...' : 'Save Order'}
            </button>
          </div>
        </div>
      )}

      {/* Phone Modal */}
      {showPhoneModal && (
        <div className="modal show fade d-block" tabIndex="-1" role="dialog">
          <div className="modal-dialog modal-dialog-centered" role="document">
            <div className="modal-content p-3">
              <h5 className="modal-title mb-3">Customer Phone</h5>
              <input
                type="text"
                className="form-control mb-3"
                placeholder="Enter phone number"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
              />
              <div className="d-flex justify-content-end gap-2">
                <button className="btn btn-secondary" onClick={() => setShowPhoneModal(false)}>Cancel</button>
                <button className="btn btn-primary" onClick={handlePhoneSubmit} disabled={loading}>
                  Confirm
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Stock;
