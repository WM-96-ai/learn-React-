import React from 'react';

const NewHome = () => {
    return (
        <div className="container mt-5">
            <div className="card shadow-sm p-4">
                <h2 className="text-center text-primary">Welcome to Your Dashboard</h2>
                <p className="text-muted text-center">Use the navigation bar above to manage your profile, stock, or view orders.</p>
            </div>
        </div>
    );
};

export default NewHome;
