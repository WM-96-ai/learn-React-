import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const LowStock = () => {
    const [items, setItems] = useState([]);
    const [searchLimit, setSearchLimit] = useState(20);
    const [searchTerm, setSearchTerm] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;

    useEffect(() => {
        const fetchItems = async () => {
            try {
                const res = await axios.get('http://localhost:3003/items');
                setItems(res.data);
            } catch (err) {
                console.error('Failed to fetch items');
            }
        };
        fetchItems();
    }, []);

    const filtered = items.filter(item => {
        const matchesSearch =
            item.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            item.itemNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
            item.batchNo.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesSearch && item.quantity < searchLimit;
    });

    const totalPages = Math.ceil(filtered.length / itemsPerPage);
    const paginated = filtered.slice(
        (currentPage - 1) * itemsPerPage,
        currentPage * itemsPerPage
    );

    return (
        <div className="container mt-4">
            <h1 className="text-center mb-4 text-warning">Low Stock Items</h1>

            <div className="row mb-3">
                <div className="col-md-6">
                    <input
                        type="text"
                        className="form-control"
                        placeholder="Search by name, number or batch"
                        value={searchTerm}
                        onChange={(e) => {
                            setSearchTerm(e.target.value);
                            setCurrentPage(1);
                        }}
                    />
                </div>
                <div className="col-md-6">
                    <input
                        type="number"
                        className="form-control"
                        placeholder="Enter quantity limit (e.g. 10)"
                        value={searchLimit}
                        onChange={(e) => {
                            setSearchLimit(parseInt(e.target.value, 10) || 0);
                            setCurrentPage(1);
                        }}
                    />
                </div>
            </div>

            <div className="table-responsive">
                <table className="table table-bordered table-hover">
                    <thead className="table-warning">
                        <tr>
                            <th>Batch No</th>
                            <th>Item No</th>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Expiry Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {paginated.map(item => (
                            <tr key={item.itemNo}>
                                <td>{item.batchNo}</td>
                                <td>{item.itemNo}</td>
                                <td>{item.itemName}</td>
                                <td>{item.quantity}</td>
                                <td>{new Date(item.expiryDate).toLocaleDateString()}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            <nav className="mt-3 d-flex justify-content-center">
                <ul className="pagination">
                    <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                        <button className="page-link" onClick={() => setCurrentPage(currentPage - 1)}>Previous</button>
                    </li>
                    {Array.from({ length: totalPages }, (_, index) => (
                        <li key={index} className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}>
                            <button className="page-link" onClick={() => setCurrentPage(index + 1)}>{index + 1}</button>
                        </li>
                    ))}
                    <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                        <button className="page-link" onClick={() => setCurrentPage(currentPage + 1)}>Next</button>
                    </li>
                </ul>
            </nav>
        </div>
    );
};

export default LowStock;
