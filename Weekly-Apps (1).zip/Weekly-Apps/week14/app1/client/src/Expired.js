import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const Expired = () => {
    const [expiredItems, setExpiredItems] = useState([]);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;

    const isExpired = (expiryDate) => {
        const today = new Date();
        const expiry = new Date(expiryDate);
        today.setHours(0, 0, 0, 0);
        expiry.setHours(0, 0, 0, 0);
        return expiry <= today;
    };

    useEffect(() => {
        const fetchExpiredItems = async () => {
            try {
                const res = await axios.get('http://localhost:3003/items');
                const expired = res.data.filter(item => isExpired(item.expiryDate));
                setExpiredItems(expired);
            } catch (err) {
                setError('Failed to fetch expired items.');
            } finally {
                setLoading(false);
            }
        };
        fetchExpiredItems();
    }, []);

    const filtered = expiredItems.filter(item => {
        const term = searchTerm.toLowerCase();
        return (
            item.itemName.toLowerCase().includes(term) ||
            item.itemNo.toLowerCase().includes(term) ||
            item.batchNo.toLowerCase().includes(term)
        );
    });

    const totalPages = Math.ceil(filtered.length / itemsPerPage);
    const paginated = filtered.slice(
        (currentPage - 1) * itemsPerPage,
        currentPage * itemsPerPage
    );

    return (
        <div className="container mt-4">
            <h1 className="text-center mb-4 text-danger">Expired Stock Items</h1>
            {error && <div className="alert alert-danger text-center">{error}</div>}
            <input
                type="text"
                className="form-control mb-3"
                placeholder="Search by item name, number or batch"
                value={searchTerm}
                onChange={(e) => {
                    setSearchTerm(e.target.value);
                    setCurrentPage(1);
                }}
            />
            {loading ? (
                <div className="text-center">Loading...</div>
            ) : (
                <div className="table-responsive">
                    <table className="table table-bordered table-hover">
                        <thead className="table-danger">
                            <tr>
                                <th>Batch No</th>
                                <th>Item No</th>
                                <th>Item Name</th>
                                <th>Quantity</th>
                                <th>Expiry Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            {paginated.map(item => (
                                <tr key={item.itemNo}>
                                    <td>{item.batchNo}</td>
                                    <td>{item.itemNo}</td>
                                    <td>{item.itemName}</td>
                                    <td>{item.quantity}</td>
                                    <td>{new Date(item.expiryDate).toLocaleDateString()}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
            {/* Pagination */}
            <nav className="mt-3 d-flex justify-content-center">
                <ul className="pagination">
                    <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
                        <button className="page-link" onClick={() => setCurrentPage(currentPage - 1)}>Previous</button>
                    </li>
                    {Array.from({ length: totalPages }, (_, index) => (
                        <li key={index} className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}>
                            <button className="page-link" onClick={() => setCurrentPage(index + 1)}>{index + 1}</button>
                        </li>
                    ))}
                    <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
                        <button className="page-link" onClick={() => setCurrentPage(currentPage + 1)}>Next</button>
                    </li>
                </ul>
            </nav>
        </div>
    );
};

export default Expired;
