import React from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

const DashboardLayout = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem('token');
        navigate('/Home');
    };

    return (
        <div>
            {/* Navbar */}
            <nav className="navbar navbar-expand-lg navbar-dark bg-primary px-4">
                <span className="navbar-brand">Pharmacy App</span>

                {/* Collapsible nav content */}
                <div className="collapse navbar-collapse justify-content-center">
                    <ul className="navbar-nav mx-auto">
                        <li className="nav-item">
                            <Link className="nav-link fw-bold" to="/NewHome">Home</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link fw-bold" to="/edit-profile">Edit Profile</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link fw-bold" to="/change-password">Change Password</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link fw-bold" to="/stock">Stock</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link fw-bold" to="/manage-items">Manage Items</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link fw-bold" to="/orders">Orders</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link fw-bold" to="/expired">Expired</Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link fw-bold" to="/low-stock">Low Stock</Link>
                        </li>

                    </ul>
                    <button className="btn btn-light btn-sm ms-lg-auto" onClick={handleLogout}>
                        Logout
                    </button>
                </div>
            </nav>

            {/* Route content */}
            <div className="p-4">
                <Outlet />
            </div>
        </div>
    );
};

export default DashboardLayout;
