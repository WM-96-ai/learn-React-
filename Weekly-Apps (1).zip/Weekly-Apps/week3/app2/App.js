import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';

function greet1(){
  return "Hello from Advanced Web Technologies";
}

function product(n){
  return n * n;
}

function add(a,b){
  return a+b;
}

const greet2 =()=> "Hello from Advanced Web Technologies 2";

const product2 =(m)=> m*m;

const add2 =(x,y)=> x+y;

function App() {
  return (
    <div className="App">
      <p>{greet1()}</p>
      <p>{product(5)}</p>
      <p>{add(4,5)}</p>
      <p>{greet2()}</p>
      <p>{product2(3)}</p>
      <p>{add2(7,8)}</p>
    </div>
  );
}

export default App;
