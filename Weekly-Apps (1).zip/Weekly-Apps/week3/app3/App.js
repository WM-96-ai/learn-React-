import PatientHeader from "./PatientComps/PatientHeader";
import PatientFooter from "./PatientComps/PatientFooter";
import PatientDetails from "./PatientComps/PatientDetails";
import "bootstrap/dist/css/bootstrap.min.css";
function App() {
  return (
    <>
      <PatientHeader />
      <PatientDetails />
      <PatientFooter />
    </>
  );
}
export default App;
