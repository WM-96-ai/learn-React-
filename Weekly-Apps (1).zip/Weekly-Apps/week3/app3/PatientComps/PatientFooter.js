import React, { useState } from "react";
const PatientFooter = () => {
  const [preparedBy, setpreparedBy] = useState("Mohammed Al-Ajmi");
  const [preparedOn, setpreparedOn] = useState(Date());
  const [barCode, setBarCode] = useState(Math.random());
  return (
    <>
      <div className="row">
        <div className="col-8">
          <h3>Prepared by {preparedBy}</h3>
        </div>
        <div className="col-10">
          <h3>Printed On: {preparedOn}</h3>
        </div>
        <div className="col-8">
          <h3>BarCode: {barCode}</h3>
        </div>
      </div>
    </>
  );
};

export default PatientFooter;
