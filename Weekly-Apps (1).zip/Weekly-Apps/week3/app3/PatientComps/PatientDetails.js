import patients from "./data.json";

const PatientDetails = () => {
  const curYear = new Date().getFullYear();
  
  return (
    <>
      <div class="container">
        <p className="display-4 text-center">Patient Details</p>
        <table class="table table-striped table-bordered">
          <thead class="table-dark">
            <tr>
              <th>Patient ID</th>
              <th>Full Name</th>
              <th>Birth Year</th>
              <th>Age</th>
              <th>Nationality</th>
              <th>Visit Fee</th>
            </tr>
          </thead>

          <tbody className="table-group-divider">
            {patients.map((patient) => {
              return (
                <tr>
                  <td>{patient.patientId}</td>
                  <td>{patient.pName + " - " + patient.lastName}</td>
                  <td>{patient.birthYear}</td>
                  <td>{curYear - patient.birthYear}</td>
                  <td>{patient.nationality}</td>
                  <td>{patient.nationality === "Oman" ? patient.regPrice : patient.regPrice + 5}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default PatientDetails;
