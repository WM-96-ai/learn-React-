import Logo from "./hospital-logo.jpg";

const PatientHeader = () => {
  return (
    <>
      <div class="container-fluid d-flex justify-content-center">
        <img src={Logo} alt="" style={{ height: "10%", width: "10%" }} />
      </div>
    </>
  );
};

export default PatientHeader;
